package Model

import com.google.firebase.storage.StorageReference

data class AmigosActivos(
    var id: String? = "",
    var nombre: String? = "",
    var latitud: Double? = 0.0,
    var longitud: Double? = 0.0,
    var distancia: Double? = 0.0,
    var foto: StorageReference? = null,
)
