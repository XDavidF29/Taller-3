package com.example.bienestar360.models

import android.net.Uri

data class Amigos(
    var nombre: String? = "",
    var email: String? = "",
    var password: String? = "",
    var imagen: Uri? = Uri.EMPTY,
    var identificacion: String? = "",
    var latitud: Double? = 0.0,
    var longitud: Double? = 0.0,
)
