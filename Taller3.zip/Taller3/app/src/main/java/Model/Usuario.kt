package com.example.bienestar360.models

import android.content.Intent
import android.net.Uri
import android.widget.ImageView
import java.util.Date

data class Usuario(var nombre: String? = "",
                   var email: String? = "",
                   var password: String? = "",
                   var imagen: Intent? = null,
                   var identificacion: String? = "",
                   var latitud: Double? = 0.0,
                   var longitud: Double? = 0.0,) {

    constructor() : this("", "", "",null,"", 0.0, 0.0)
}