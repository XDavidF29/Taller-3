package com.example.taller3

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.os.Bundle
import android.telecom.Call
import android.util.Log
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.bienestar360.models.Amigos
import com.example.taller3.databinding.ActivityMapaBinding
import com.google.android.gms.common.api.Response
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.MapStyleOptions
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers.Main
import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException
import java.util.logging.Logger


class MapaActivity : AppCompatActivity(), com.google.android.gms.maps.OnMapReadyCallback, GoogleMap.OnMyLocationButtonClickListener,
    SensorEventListener {
    private lateinit var map: GoogleMap

    private val database = com.google.firebase.Firebase.database

    private var start:String = ""
    private var end:String = ""
    private var poly: Polyline? = null

    private var currentPolyline: Polyline? = null

    private var apiKey:String = ""


    companion object {
        const val REQUEST_CODE_LOCATION = 0
        val TAG: String = MapaActivity::class.java.name
    }

    private val logger = Logger.getLogger(TAG)
    private var userLocationMarker: Marker? = null
    private var otherLocationMarker: Marker? = null
    private var userId: String? = null
    private lateinit var dbRef: DatabaseReference
    private lateinit var mAuth: FirebaseAuth
    private lateinit var binding: ActivityMapaBinding
    private val markersMap: HashMap<String, Marker> = HashMap()

    //esto es lo del menu pequeño de opciones de salir o hacer la ruta!!!
    private val rotateOpen: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.rotate_open_anim) }
    private val rotateClose: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.rotate_close_animation) }
    private val fromBotton: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.from_bottom_animation) }
    private val toBottom: Animation by lazy { AnimationUtils.loadAnimation(this, R.anim.to_bottom_animation) }
    private var clicked = false

    //sensor luz
    private lateinit var sensorManager: SensorManager
    private var lightSensor: Sensor? = null  // Permitir que lightSensor sea null

    // Permission handler
    private val getSimplePermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()) {
        updateUI(it)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMapaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //lo del boton de opciones
        binding.menuBtn.setOnClickListener {
            onAddButtonClicked()
        }


        // Inicialización del SensorManager y el sensor de luz
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)


        mAuth = Firebase.auth
        dbRef = FirebaseDatabase.getInstance().getReference("users")
        createFragment()
    }

    private fun onAddButtonClicked() {
        setVisibility(clicked)
        setAnimation(clicked)
        clicked = !clicked

        //Boton ubicacion del usuario autenticado
        binding.ubicacionBtn.setOnClickListener {
            Toast.makeText(this, "Mi ubicación", Toast.LENGTH_SHORT).show()

            val userLocation = LatLng(userLocationMarker?.position?.latitude ?: 0.0, userLocationMarker?.position?.longitude ?: 0.0)
            val cameraPosition = CameraPosition.builder()
                .target(userLocation)
                .zoom(15f)
                .build()
            map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition), 3000, null)
        }

        //Boton cerrar mapa
        binding.cerrarBtn.setOnClickListener{
            Toast.makeText(this, "Cerrar mapa", Toast.LENGTH_SHORT).show()

            start=""
            end=""
            poly?.remove()
            val intent = Intent(this, Main::class.java)
            startActivity(intent)
        }

        //Boton crear ruta hacia otro usuario
        binding.rutaBtn.setOnClickListener{
            Toast.makeText(this, "Crear ruta", Toast.LENGTH_SHORT).show()

            poly?.remove()
            if (poly != null){
                poly = null
            }
            drawRoute()
        }

        //Boton ubicacion de otro usuario
        binding.otroUbicacionBtn.setOnClickListener {
            Toast.makeText(this, "Ubicación del otro usuario", Toast.LENGTH_SHORT).show()

            val otherUserLocation = LatLng(otherLocationMarker?.position?.latitude ?: 0.0, otherLocationMarker?.position?.longitude ?: 0.0)
            val cameraPosition = CameraPosition.builder()
                .target(otherUserLocation)
                .zoom(15f)
                .build()
            map.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition), 3000, null)

        }

    }

    private fun setVisibility(clicked: Boolean) {
        if(!clicked){
            binding.rutaBtn.visibility = View.VISIBLE
            binding.cerrarBtn.visibility = View.VISIBLE
            binding.ubicacionBtn.visibility = View.VISIBLE
            binding.otroUbicacionBtn.visibility = View.VISIBLE
        }else{
            binding.rutaBtn.visibility = View.INVISIBLE
            binding.cerrarBtn.visibility = View.INVISIBLE
            binding.ubicacionBtn.visibility = View.INVISIBLE
            binding.otroUbicacionBtn.visibility = View.INVISIBLE
        }
    }

    private fun setAnimation(clicked: Boolean) {
        if(!clicked){
            binding.rutaBtn.startAnimation(fromBotton)
            binding.cerrarBtn.startAnimation(fromBotton)
            binding.ubicacionBtn.startAnimation(fromBotton)
            binding.otroUbicacionBtn.startAnimation(fromBotton)
            binding.menuBtn.startAnimation(rotateOpen)
        }else{
            binding.rutaBtn.startAnimation(toBottom)
            binding.cerrarBtn.startAnimation(toBottom)
            binding.ubicacionBtn.startAnimation(toBottom)
            binding.otroUbicacionBtn.startAnimation(toBottom)
            binding.menuBtn.startAnimation(rotateClose)
        }
    }



    private fun createFragment() {
        val mapFragment: SupportMapFragment =
            supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        val nombreBuscar = intent.getStringExtra("nombre")
        userId = intent.getStringExtra("UserId")
        map = googleMap
        map.uiSettings.setAllGesturesEnabled(true)
        // Add UI controls
        map.uiSettings.isZoomControlsEnabled = true
        map.uiSettings.isMapToolbarEnabled = true
        verifyPermissions(this, android.Manifest.permission.ACCESS_FINE_LOCATION, "El permiso es requerido para poder mostrar tu ubicación en el mapa")
        map.setOnMyLocationButtonClickListener(this)
        if (nombreBuscar != null) {
            obtenerUbicaciones(nombreBuscar)
        }

        obtenerValorAPIKey()
    }


    //crear ruta
    private fun drawRoute() {
        //Crear el cliente para la peticion HTTP
        val client = OkHttpClient()

        //Elimina la ruta existente si hay
        if (currentPolyline != null) {
            currentPolyline?.remove()
        }

        // Obtener las coordenadas de inicio y fin
        val start = LatLng(userLocationMarker?.position?.latitude ?: 0.0, userLocationMarker?.position?.longitude ?: 0.0)
        val end = LatLng(otherLocationMarker?.position?.latitude ?: 0.0, otherLocationMarker?.position?.longitude ?: 0.0)

        Log.d("MapaActivity", "Valor API Key: $apiKey")

        obtenerValorAPIKey()
        //Crear la URL de la peticion
        val url = "https://maps.googleapis.com/maps/api/directions/json?" +
                "origin=${start.latitude},${start.longitude}" +
                "&destination=${end.latitude},${end.longitude}" +
                "&key=${apiKey}"

        //Crear la peticion
        val request = Request.Builder()
            .url(url)
            .build()

        //Realizar la peticion
        client.newCall(request).enqueue(object : okhttp3.Callback {
            //En caso de error
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                e.printStackTrace()
            }

            @Throws(IOException::class)
            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                val jsonData = response.body?.string()
                val jsonObject = JSONObject(jsonData)

                //Extraer la informacion de la ruta desde la respuesta JSON
                val routes = jsonObject.getJSONArray("routes")
                val legs = routes.getJSONObject(0).getJSONArray("legs")
                val steps = legs.getJSONObject(0).getJSONArray("steps")

                //Crear las opciones de la linea
                val polylineOptions = PolylineOptions().color(Color.RED).width(15f)

                //Iterar sobre cada paso de la ruta
                for (i in 0 until steps.length()) {
                    //Extraer la informacion de la ubicacion de inicio y fin de cada paso
                    val startLocation = steps.getJSONObject(i).getJSONObject("start_location")
                    val endLocation = steps.getJSONObject(i).getJSONObject("end_location")

                    //Crear objetos LatLng a partir de la informacion extraida
                    val startLatLng = LatLng(startLocation.getDouble("lat"), startLocation.getDouble("lng"))
                    val endLatLng = LatLng(endLocation.getDouble("lat"), endLocation.getDouble("lng"))

                    //Agregar los puntos a la linea
                    polylineOptions.add(startLatLng, endLatLng)
                }

                //Pintar la linea en el mapa
                runOnUiThread {
                    currentPolyline = map.addPolyline(polylineOptions)
                }
            }

        })


    }

    private fun obtenerValorAPIKey() {
        val ref = database.getReference("APIKey")
        ref.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val valor = snapshot.value.toString()
                    apiKey = valor
                    Log.d("Firebase",apiKey)
                } else {
                    Log.d("Firebase", "No se encontró el valor solicitado.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.d("Firebase", "Error al obtener datos: ${error.message}")
            }
        })
    }

    private fun isLocationPermissionGranted() = ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED


    private fun verifyPermissions(context: Context, permission: String, rationale: String) {
        when {
            ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED -> {
//                Snackbar.make(binding.root, "Ya tengo los permisos 😜", Snackbar.LENGTH_LONG).show()
                updateUI(true)
            }
            shouldShowRequestPermissionRationale(permission) -> {
                // We display a snackbar with the justification for the permission, and once it disappears, we request it again.
                val snackbar = Snackbar.make(binding.root, rationale, Snackbar.LENGTH_LONG)
                snackbar.addCallback(object : Snackbar.Callback() {
                    override fun onDismissed(snackbar: Snackbar, event: Int) {
                        if (event == DISMISS_EVENT_TIMEOUT) {
                            getSimplePermission.launch(permission)
                        }
                    }
                })
                snackbar.show()
            }
            else -> {
                getSimplePermission.launch(permission)
            }
        }
    }

    private fun obtenerUbicaciones(idBuscar: String) {
        val dbRef = FirebaseDatabase.getInstance().getReference("users")

        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                // Elimina los marcadores antiguos excepto el del usuario actual
                markersMap.values.forEach {
                    if (it != userLocationMarker) {
                        it.remove()
                    }
                }
                markersMap.clear()
                for (userSnapshot in dataSnapshot.children) {
                    val usuario = userSnapshot.getValue(Amigos::class.java)
                    usuario?.let {
                        val coordinates = LatLng(it.latitud!!, it.longitud!!)
                        val markerOptions: MarkerOptions
                        val marker: Marker
                        // Establecer el color del marcador
                        if (userSnapshot.key == idBuscar && userSnapshot.key != userId) {
                            end = "${it.longitud!!},${it.latitud!!}"
                            markerOptions = MarkerOptions()
                                .position(coordinates)
                                .title(it.nombre)
                            markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_GREEN))
                            otherLocationMarker = map.addMarker(markerOptions)
                            marker = (otherLocationMarker as Marker?)!!
                            marker.let { m ->
                                markersMap[userSnapshot.key!!] = m
                            }
                            // Mover la cámara después de añadir el marcador verde
                            map.moveCamera(CameraUpdateFactory.newLatLngZoom(coordinates, 10f))
                        } else if(userSnapshot.key != userId){
                            markerOptions = MarkerOptions()
                                .position(coordinates)
                                .title(it.nombre)
                            markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                            marker = map.addMarker(markerOptions)!!
                            marker.let { m ->
                                markersMap[userSnapshot.key!!] = m
                            }
                        } else {

                        }

                    }
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(this@MapaActivity, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }


    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQUEST_CODE_LOCATION -> if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                map.isMyLocationEnabled == true
            } else {
                Toast.makeText(this, "Para activar la localizacion ve a ajustes y acepta los permisos", Toast.LENGTH_SHORT).show()
            }

            else -> {}
        }
    }

    @SuppressLint("MissingPermission")
    override fun onResumeFragments() {
        super.onResumeFragments()
        if (!::map.isInitialized) return
        if(!isLocationPermissionGranted()){
            map.isMyLocationEnabled = false
            Toast.makeText(this, "Para activar la localizacion ve a ajustes y acepta los permisos", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onMyLocationButtonClick(): Boolean {
        Toast.makeText(this, "Boton pulsado", Toast.LENGTH_SHORT).show()
        return false
    }



    @SuppressLint("MissingPermission")
    fun updateUI(permission: Boolean) {
        if (permission) {
            // granted
            logger.info("Permission granted")

            val locationCallback: LocationCallback
            val fusedLocationClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)

            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                if (location != null) {
                    val ubicacion = LatLng(location.latitude, location.longitude)
                    if (userLocationMarker == null) {
                        start = "${location.longitude},${location.latitude}"
                        userLocationMarker = map.addMarker(
                            MarkerOptions().position(ubicacion)
                                .title("Mi posición actual")
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                        )
                    } else {
                        // Actualiza la posición del marcador existente
                        userLocationMarker?.position = ubicacion
                    }
                }
            }

            locationCallback = object : LocationCallback() {
                override fun onLocationResult(locationResult: LocationResult) {
                    locationResult.locations.forEach { location ->
                        val newLatLng = LatLng(location.latitude, location.longitude)

                        // Actualiza Firebase con la nueva ubicación
                        val userId = mAuth.currentUser?.uid
                        if (userId != null) {
                            dbRef.child(userId).child("latitud").setValue(location.latitude)
                            dbRef.child(userId).child("longitud").setValue(location.longitude)
                        }

                        start = "${location.longitude},${location.latitude}"

                        // Actualiza el marcador en el mapa
                        //if (userLocationMarker == null) {
                        userLocationMarker?.remove()
                        userLocationMarker = map.addMarker(
                            MarkerOptions().position(newLatLng)
                                .title("Mi posición actual")
                                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                        )
                    }
                }
            }


            val locationRequest = LocationRequest.create().apply {
                interval = 10000 // Intervalo de actualización de ubicación en milisegundos
                fastestInterval = 5000
                priority = LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY
            }

            val builder = LocationSettingsRequest.Builder()
                .addLocationRequest(locationRequest)

            // Verifica la configuración de ubicación
            val client = LocationServices.getSettingsClient(this)
            val task = client.checkLocationSettings(builder.build())

            task.addOnSuccessListener {
                // Configuración de ubicación aceptada, comienza la actualización
                fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null)
            }

        } else {
            logger.warning("Permission denied")
        }
    }
    override fun onSensorChanged(event: SensorEvent?) {
        try {
            event?.values?.let {
                if (it.isNotEmpty() && event.sensor.type == Sensor.TYPE_LIGHT) {
                    val lux = it[0]
                    runOnUiThread {
                        try {
                            if (lux > 35) {
                                map?.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_day))
                            } else {
                                map?.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_night))
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error applying map style", e)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing sensor data", e)
        }
    }



    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // Manejo de cambios de precisión del sensor
    }

    override fun onResume() {
        super.onResume()
        lightSensor?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        } ?: run {
            Toast.makeText(this, "Sensor de luz no disponible", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onPause() {
        super.onPause()
        lightSensor?.let {
            sensorManager.unregisterListener(this)
        }
    }
}