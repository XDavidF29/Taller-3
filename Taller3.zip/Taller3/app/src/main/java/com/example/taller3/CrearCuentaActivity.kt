package com.example.taller3

import Utils.Alerts
import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.example.bienestar360.models.Usuario
import com.example.taller3.databinding.ActivityCrearCuentaBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.database.database
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.storage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class CrearCuentaActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCrearCuentaBinding

    private val alerts = Alerts(this)

    private var auth: FirebaseAuth = Firebase.auth
    private val database = Firebase.database
    private val storage = Firebase.storage
    private var takePictureIntent: Intent? = null
    private var intentPick: Intent? = null

    private val PERM_CAMERA_CODE = 101
    private val REQUEST_IMAGE_CAPTURE = 10
    private val PERM_GALERY_GROUP_CODE = 202
    private val REQUEST_PICK = 3
    private var outputPath: Uri? = null

//    private val refData = database.getReference("users/${currentUser?.uid}")




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCrearCuentaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.botonRegistrarse.setOnClickListener {
            var intentEnvio: Intent? = null
            if(!(takePictureIntent == null && intentPick == null)){
                if(takePictureIntent != null){
                    intentEnvio = takePictureIntent
                }
                else{
                    intentEnvio = intentPick
                }

                registrarUsuario(binding.registerName.toString(),
                    binding.registerEmail.toString(),
                    binding.registerContrasena.toString(), intentEnvio,
                    binding.identificacion.toString(), 0.0, 0.0)


            }

            }

        binding.txtYaTengoCuenta.setOnClickListener {
            startActivity(Intent(this, InicioSesionActivity::class.java))
        }

        binding.profilePhotoBtn.setOnClickListener {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED -> {
                    takePhoto()
                }

                shouldShowRequestPermissionRationale(Manifest.permission.CAMERA) -> {
                    alerts.indefiniteSnackbar(
                        binding.root,
                        "El permiso de Camara es necesario para actualizar la foto de perfil"
                    )
                }

                else -> {
                    requestPermissions(arrayOf(Manifest.permission.CAMERA), PERM_CAMERA_CODE)
                }
            }
        }
        binding.profileGalleryBtn.setOnClickListener {
            when {
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED -> {
                    startGallery()
                }

                shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE) -> {
                    alerts.indefiniteSnackbar(
                        binding.root,
                        "El permiso de Galeria es necesario para actualizar la foto de perfil"
                    )
                }

                else -> {
                    val permissions = arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                        permissions.plus(Manifest.permission.READ_MEDIA_IMAGES)
                    }
                    requestPermissions(permissions, PERM_GALERY_GROUP_CODE)
                }
            }
        }
    }

    private fun validarCampos(): Boolean {
        //Validar campo nombre de usuario
        if (binding.registerName.editText?.text.toString().isEmpty()) {
            binding.registerName.error = getString(R.string.error_name_label)
            return false
        } else binding.registerName.isErrorEnabled = false;
        // Validar campo email
        if (binding.registerEmail.editText?.text.toString().isEmpty() ||
            !android.util.Patterns.EMAIL_ADDRESS.matcher(binding.registerEmail.editText?.text.toString())
                .matches()
        ) {
            binding.registerEmail.error = getString(R.string.mail_error_label)
            return false
        } else binding.registerEmail.isErrorEnabled = false;
        // Validar primer campo password
        if (binding.registerContrasena.editText?.text.toString().isEmpty()) {
            binding.registerContrasena.error = getString(R.string.error_pass_label);
            return false
        } else binding.registerContrasena.isErrorEnabled = false;
        //Validar segundo campo password
        if(binding.registerContrasena1.editText?.text.toString().isEmpty()){
            binding.registerContrasena1.error = getString(R.string.error_pass_label);
            return false
        } else binding.registerContrasena1.isErrorEnabled = false;
        //Validar que ambas contrasenas sean iguales
        if(binding.registerContrasena.editText?.text.toString() != binding.registerContrasena1.editText?.text.toString()){
            binding.registerContrasena.error = getString(R.string.error_pass_match)
            binding.registerContrasena1.error = getString(R.string.error_pass_match);
            return false
        }

        return true
    }

    private fun startGallery() {
        intentPick = Intent(Intent.ACTION_PICK)
        intentPick!!.type = "image/*"
        startActivityForResult(intentPick!!, REQUEST_PICK)
    }

    private fun takePhoto() {
        takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.getDefault()).format(
            Date()
        )
        val imageFileName = "JPEG_${timeStamp}_.jpg"
        val imageFile = File(getExternalFilesDir(Environment.DIRECTORY_PICTURES).toString() + "/" + imageFileName)
        outputPath = FileProvider.getUriForFile(
            this,
            "com.bienestar360.fileprovider",
            imageFile
        )
        takePictureIntent!!.putExtra(MediaStore.EXTRA_OUTPUT, outputPath)
        try {
            startActivityForResult(takePictureIntent!!, REQUEST_IMAGE_CAPTURE)
        } catch (e: ActivityNotFoundException) {
            e.localizedMessage?.let { alerts.indefiniteSnackbar(binding.root, it) }
        }
    }

    private fun registrarUsuario(nombre: String, email: String, password: String, imagen: Intent?, identificacion: String, latitud: Double?, longitud: Double?) {
        val auth = FirebaseAuth.getInstance()
        val db = FirebaseFirestore.getInstance()

        // Crea el usuario con el correo y contraseña en Firebase Authentication
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Obtiene el UID del usuario recién creado
                    val userId = auth.currentUser?.uid
                    if (userId != null) {
                        // Crea una instancia de Usuario con los datos proporcionados
                        val usuario = Usuario(
                            nombre = nombre,
                            email = email,
                            password = password,
                            imagen = imagen, // Usa Uri.EMPTY si no se proporciona una URI válida
                            identificacion = identificacion,
                            latitud = latitud ?: 0.0, // Usa 0.0 si no se proporciona latitud
                            longitud = longitud ?: 0.0 // Usa 0.0 si no se proporciona longitud
                        )

                        // Guarda el usuario en Firestore (asumiendo que quieres guardarlo en una colección "usuarios")
                        db.collection("usuarios").document(userId)
                            .set(usuario)
                            .addOnSuccessListener {
                                Toast.makeText(this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show()
                            }
                            .addOnFailureListener { e ->
                                Toast.makeText(this, "Error al registrar usuario: ${e.message}", Toast.LENGTH_SHORT).show()
                            }
                    }
                } else {
                    // Si hubo un error en la creación del usuario en Firebase Authentication
                    Toast.makeText(this, "Error al crear cuenta: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }
}