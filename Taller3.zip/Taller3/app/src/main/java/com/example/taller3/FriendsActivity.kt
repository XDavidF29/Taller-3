package com.example.taller3

import Model.AmigosActivos
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.bienestar360.adapters.AmigosAdapter
import com.example.bienestar360.models.Amigos
import com.example.taller3.databinding.ActivityFriendsBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storage
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

class FriendsActivity: AppCompatActivity() {

    private lateinit var binding: ActivityFriendsBinding
    private lateinit var dbRef: DatabaseReference
    private lateinit var mAuth: FirebaseAuth
    private val storage = com.google.firebase.ktx.Firebase.storage
    private lateinit var refProfileImg: StorageReference


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFriendsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mAuth = Firebase.auth

    }

    //aca empieza
    override fun onResume() {
        super.onResume()
        mAuth = Firebase.auth
        var idUsuario = mAuth.currentUser?.uid.toString()
        // Imprimir el ID de usuario en el registro (log)
        Log.d("ID_USUARIO", "ID de usuario: $idUsuario")
        /*idUsuario = "2GTGXiT9SNd45bxD4I47kz2PG1F2"*/

        val dbRef = FirebaseDatabase.getInstance().getReference("users/$idUsuario")

        dbRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                val latitud = dataSnapshot.child("latitud").getValue(Double::class.java)
                val longitud = dataSnapshot.child("longitud").getValue(Double::class.java)

                if (latitud != null && longitud != null) {
                    // Aquí puedes usar latitud y longitud
                    println("Latitud: $latitud, Longitud: $longitud")
                    initRecyclerView(idUsuario, latitud, longitud)
                } else {
                    println("No se encontraron las coordenadas.")
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                println("Error al acceder a la base de datos: ${databaseError.message}")
            }
        })

    }

    private fun initRecyclerView(idUsuario: String?, latitud: Double?, longitud: Double?) {
        val manager = LinearLayoutManager(this)
        binding.recyclerAmigos.layoutManager = manager

        val amigosList = mutableListOf<Amigos>()
        var amigosActivos = mutableListOf<AmigosActivos>()
        val dbRef = FirebaseDatabase.getInstance().getReference("users")

        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                amigosList.clear()
                amigosActivos.clear()
                for (userSnapshot in dataSnapshot.children) {
                    val usuario = userSnapshot.getValue(Amigos::class.java)
                    var idsecundario = userSnapshot.key
                    usuario?.let {
                        if(userSnapshot.key != idUsuario){
                            amigosList.add(it)
                            // Calcular la distancia
                            refProfileImg = storage.reference.child("users/${userSnapshot.key}/profile.jpg")
                            val distancia = haversine(latitud!!, longitud!!, it.latitud!!, it.longitud!!)
                            amigosActivos.add(AmigosActivos(userSnapshot.key, it.nombre, it.latitud, it.longitud, distancia, refProfileImg))
                        }
                    }
                }
                // Crear el adaptador con la nueva lista de amigos
                val adapter = AmigosAdapter(amigosActivos) { amigos ->
                    onItemSelected(amigos, idUsuario)
                }
                // Asignar el adaptador al RecyclerView
                binding.recyclerAmigos.adapter = adapter
            }

            override fun onCancelled(databaseError: DatabaseError) {
                // Manejar los errores si es necesario
                Toast.makeText(this@FriendsActivity, "Error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    fun onItemSelected(amigos: AmigosActivos, userId:String?){
        Toast.makeText(this, amigos.nombre ?: "Nombre no disponible", Toast.LENGTH_SHORT).show()
        val intent = Intent(this@FriendsActivity, MapaActivity::class.java)
        intent.putExtra("nombre", amigos.id) // Se tiene que cambiar por un atributo que no se repita
        intent.putExtra("UserId", userId)
        startActivity(intent)
    }

    fun haversine(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371.0 // Radio de la Tierra en kilómetros
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return R * c
    }

}