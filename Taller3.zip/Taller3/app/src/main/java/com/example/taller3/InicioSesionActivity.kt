package com.example.taller3

import Utils.Alerts
import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.taller3.databinding.ActivityInicioSesionBinding
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class InicioSesionActivity : AppCompatActivity() {
    private lateinit var binding: ActivityInicioSesionBinding
    private val alerts = Alerts(this)

    private var auth: FirebaseAuth = Firebase.auth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInicioSesionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.botonIniciarSesion.setOnClickListener {
            login()
        }

        binding.botonOlvideContra.setOnClickListener {
            recuperarContrasena()
        }

        binding.botonCrearNuevaCuenta.setOnClickListener {
            startActivity(Intent(this, CrearCuentaActivity::class.java))
        }
    }

    private fun validarCampos(): Boolean {
        // Validar campo email
        if (binding.loginEmail.editText?.text.toString().isEmpty() ||
            !android.util.Patterns.EMAIL_ADDRESS.matcher(binding.loginEmail.editText?.text.toString())
                .matches()
        ) {
            binding.loginEmail.error = getString(R.string.mail_error_label)
            return false
        } else binding.loginEmail.isErrorEnabled = false
        // Validar campo password
        if (binding.loginContrasena.editText?.text.toString().isEmpty()) {
            binding.loginContrasena.error = getString(R.string.error_pass_label);
            return false
        } else binding.loginContrasena.isErrorEnabled = false;
        return true
    }

    private fun login(){
        if (validarCampos())
            auth.signInWithEmailAndPassword(
                binding.loginEmail.editText?.text.toString(),
                binding.loginContrasena.editText?.text.toString()
            ).addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    //Si el login es correcto, se redirige al menu principal
                    startActivity(Intent(this@InicioSesionActivity, MainActivity::class.java))
                } else {
                    // Si el login no es correcto, se muestra un mensaje de error.
                    task.exception?.localizedMessage?.let {
                        alerts.indefiniteSnackbar(
                            binding.root,
                            it
                        )
                    }
                }
            }
    }

    fun recuperarContrasena() {
        // Validate email
        if (binding.loginEmail.editText?.text.toString().isEmpty() ||
            !android.util.Patterns.EMAIL_ADDRESS.matcher(binding.loginEmail.editText?.text.toString())
                .matches()
        ) {
            binding.loginEmail.error = getString(R.string.mail_error_label)
            return
        } else binding.loginEmail.isErrorEnabled = false
        auth.sendPasswordResetEmail(
            binding.loginEmail.editText?.text.toString()
        )
            .addOnCompleteListener(this) { task ->
                var msg: String = ""
                if (task.isSuccessful) {
                    msg = "Email enviado, revise su correo."
                } else {
                    task.exception?.localizedMessage?.let {
                        msg = it
                    }
                }
                alerts.indefiniteSnackbar(
                    binding.root,
                    msg
                )
            }
    }
}