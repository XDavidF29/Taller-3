package com.example.bienestar360.adapters

import android.text.Html
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.bienestar360.R
import com.example.bienestar360.models.AmigosActivos
import com.example.bienestar360.databinding.ItemAmigosBinding

class AmigosViewHolder(view:View):RecyclerView.ViewHolder(view) {

    val binding= ItemAmigosBinding.bind(view)

    fun render(amigosModel: AmigosActivos, onClickListener:(AmigosActivos) -> Unit){
        binding.tvAmigosName.text = amigosModel.nombre
        val distancia = String.format(itemView.context.getString(R.string.distancia_text), amigosModel.distancia)
        binding.distanciaTxt.text = Html.fromHtml(distancia)
        Glide.with(binding.imageViewContact.context)
            .load(amigosModel.foto)
            .diskCacheStrategy(DiskCacheStrategy.NONE) // Evita el uso de cache en disco
            .skipMemoryCache(true) // Evita el uso de la cache en memoria
            .centerCrop()
            .into(binding.imageViewContact)
        itemView.setOnClickListener { onClickListener(amigosModel) }
    }
}