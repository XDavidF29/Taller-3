package com.example.bienestar360.adapters

import Model.AmigosActivos
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.taller3.R

class AmigosAdapter(private val amigosList:List<AmigosActivos>, private val onClickListener:(AmigosActivos) -> Unit) :RecyclerView.Adapter<AmigosViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AmigosViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        return AmigosViewHolder(layoutInflater.inflate(R.layout.item_amigos, parent, false))
    }

    override fun onBindViewHolder(holder: AmigosViewHolder, position: Int) {
        val item = amigosList[position]
        holder.render(item, onClickListener)
    }

    override fun getItemCount(): Int = amigosList.size

}