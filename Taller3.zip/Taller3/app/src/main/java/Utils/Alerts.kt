package Utils

import android.content.Context
import android.util.Log
import android.view.View
import android.widget.Toast
import com.example.taller3.R
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

class Alerts constructor(private val context: Context) {
    private var TAG = Alerts::class.java.name

    fun indefiniteSnackbar(parentView: View, message: String) {
        Log.i(TAG, "indefiniteSnackbar: $message")
        val snackbar = Snackbar.make(parentView, message, Snackbar.LENGTH_INDEFINITE)
        snackbar.setAction(R.string.snackBar_dismiss_label) { snackbar.dismiss() }
        snackbar.show()
    }
    fun showDialog(
        title: String,
        message: String,
        positiveButton: String = context.getString(R.string.snackBar_dismiss_label),
        negativeButton: String = context.getString(R.string.cancel_label),
        positiveAction: () -> Unit = {},
        negativeAction: () -> Unit = {}
    ) {
        MaterialAlertDialogBuilder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(positiveButton) { dialog, _ ->
                positiveAction()
                dialog.dismiss()
            }
            .setNegativeButton(negativeButton) { dialog, _ ->
                negativeAction()
                dialog.dismiss()
            }
            .show()
    }

}